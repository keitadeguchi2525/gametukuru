using System.Collections.Generic;
using UnityEngine;

// 試作01 本体。空のGameObjectにこれを付けてPlayするだけで動く
public class ProtoGame : MonoBehaviour
{
    public enum EnemyState { Idle, Attack, Break, Dead }
    enum Mode { Title, Fight, Result, Shop }

    public class Attack
    {
        public char dir, need;
        public float W, t;
        public bool struck, failed, parried, warned;
    }

    class Weapon
    {
        public string id, name, desc;
        public float mul, brk;
        public Dictionary<string, int> req;
    }

    [Tooltip("日本語が□で表示される場合は、日本語フォント（.ttf/.otf）をここに入れる")]
    public Font uiFont;

    [Header("調整用の数値")]
    public float parryWindow = 0.3f;      // パリィの受付時間（攻撃が当たる何秒前から）
    public float enemyMaxHp = 260f;
    public float playerMaxHp = 100f;
    public int maxShield = 4;
    [Range(0f, 1f)] public float rareDropRate = 0.2f;

    // --- シーン ---
    Camera cam;
    Transform sword, shieldT;
    Renderer shieldR;
    Material darkMat, rockMat, sparkMat, sparkWMat, redMat;
    ProtoEnemy enemy;
    ProtoAudio sfx;
    readonly Vector3 CAM = new Vector3(0, 2.3f, -3.4f), LOOK = new Vector3(0, 2.7f, 4.5f);

    // --- 状態 ---
    Mode mode = Mode.Title;
    float time;
    float pHp, dodgeT, dodgeCd; int pShield, dodgeDir; bool guard;
    float eHp, idleT, breakT, deadT; EnemyState eState = EnemyState.Idle;
    readonly List<char> chain = new List<char>(); int idx, chainOK; bool chainHit, tParry, tDodge, tBlock;
    Attack atk; int slashN, parryCombo;
    float hitstop, shake, punch, hurtFlash, winDelay = -1f;

    Dictionary<string, int> inv = new Dictionary<string, int> { { "甲殻", 0 }, { "爪", 0 }, { "棘", 0 }, { "角", 0 }, { "紅玉", 0 } };
    Dictionary<string, int> fightLoot = new Dictionary<string, int>();
    readonly HashSet<string> owned = new HashSet<string> { "scrap" };
    List<Weapon> weapons;
    Weapon weapon;
    string resTitle = "", resSub = "", resLoot = "";
    string msgText = ""; Color msgColor = Color.black; float msgT; int msgSize = 34;

    // --- 入力 ---
    bool dragging, dragDone; Vector2 drag0; readonly List<Vector2> dragPts = new List<Vector2>();
    char swingDir; float swingT = -1f;

    // --- 演出 ---
    class Spark { public Transform t; public Vector3 v; public float life; }
    readonly List<Spark> sparks = new List<Spark>();
    class Trail { public LineRenderer lr; public List<Vector2> pts; public float life, max; public Color c; }
    readonly List<Trail> trails = new List<Trail>();
    Material lineMat;

    static readonly Dictionary<char, char> NEED = new Dictionary<char, char> { { 'R', 'L' }, { 'L', 'R' }, { 'D', 'U' } };
    static readonly Dictionary<char, string> ARROW = new Dictionary<char, string> { { 'L', "←" }, { 'R', "→" }, { 'U', "↑" }, { 'D', "↓" } };

    // ================= セットアップ =================
    void Start()
    {
        weapons = new List<Weapon>
        {
            new Weapon { id = "scrap", name = "残骸ブレード", mul = 1.0f, desc = "船の残骸から削り出した刃" },
            new Weapon { id = "shell", name = "甲殻ブレード", mul = 1.5f, desc = "攻撃 ×1.5", req = new Dictionary<string, int> { { "甲殻", 3 }, { "爪", 1 } } },
            new Weapon { id = "spine", name = "棘の刃", mul = 1.25f, brk = 0.7f, desc = "攻撃 ×1.25／崩し +0.7秒", req = new Dictionary<string, int> { { "棘", 2 }, { "甲殻", 2 } } },
            new Weapon { id = "horn", name = "角の大剣", mul = 2.2f, desc = "攻撃 ×2.2（紅玉は低確率）", req = new Dictionary<string, int> { { "角", 2 }, { "紅玉", 1 } } },
        };
        weapon = weapons[0];
        sfx = gameObject.AddComponent<ProtoAudio>();
        BuildScene();
        ResetFight();
    }

    void BuildScene()
    {
        Color bg = new Color(0.914f, 0.906f, 0.886f);
        cam = Camera.main;
        if (cam == null) { var cg = new GameObject("Main Camera"); cg.tag = "MainCamera"; cam = cg.AddComponent<Camera>(); cg.AddComponent<AudioListener>(); }
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = bg;
        cam.nearClipPlane = 0.05f;
        cam.fieldOfView = 60f;

        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = bg;
        RenderSettings.fogStartDistance = 12f;
        RenderSettings.fogEndDistance = 34f;
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.62f, 0.61f, 0.59f);

        var lg = new GameObject("Proto Sun");
        var light = lg.AddComponent<Light>();
        light.type = LightType.Directional; light.intensity = 0.9f; light.shadows = LightShadows.Soft;
        lg.transform.rotation = Quaternion.Euler(50f, -30f, 0);

        var groundMat = ProtoBuild.Lit(new Color(0.847f, 0.835f, 0.808f));
        rockMat = ProtoBuild.Lit(new Color(0.81f, 0.8f, 0.77f));
        darkMat = ProtoBuild.Lit(new Color(0.18f, 0.17f, 0.2f));
        sparkMat = ProtoBuild.Unlit(new Color(1f, 0.48f, 0.1f));
        sparkWMat = ProtoBuild.Unlit(Color.white);
        redMat = ProtoBuild.Unlit(new Color(0.78f, 0.06f, 0.18f));
        lineMat = ProtoBuild.LineMat();

        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground"; ground.transform.localScale = new Vector3(8, 1, 8);
        ground.GetComponent<Renderer>().sharedMaterial = groundMat;

        // 惑星の岩柱
        var rocks = new GameObject("Rocks").transform;
        var r = new System.Random(7);
        for (int i = 0; i < 26; i++)
        {
            float h = Rand(r, 2f, 11f), w = Rand(r, 0.4f, 1.4f), ang = Rand(r, -1.3f, 1.3f), dist = Rand(r, 10f, 26f);
            var g = ProtoBuild.Box("Rock", new Vector3(w, h, w), new Vector3(Mathf.Sin(ang) * dist, h / 2f, Mathf.Cos(ang) * dist + 3f), rockMat, rocks, false);
            g.transform.rotation = Quaternion.Euler(0, Rand(r, 0, 180f), Rand(r, -5f, 5f));
        }
        // 墜落した船の残骸
        var wreck = ProtoBuild.Box("Wreck", new Vector3(3.5f, 0.8f, 1.6f), new Vector3(-7.5f, 0.3f, 9f), darkMat, null, false);
        wreck.transform.rotation = Quaternion.Euler(-6f, -40f, 14f);

        // 一人称の剣と盾
        sword = new GameObject("Sword").transform;
        sword.SetParent(cam.transform, false);
        var bladeMat = ProtoBuild.Lit(new Color(0.965f, 0.96f, 0.945f));
        ProtoBuild.Box("Blade", new Vector3(0.022f, 0.022f, 0.56f), new Vector3(0, 0, 0.28f), bladeMat, sword, false);
        ProtoBuild.Box("Hilt", new Vector3(0.032f, 0.032f, 0.12f), new Vector3(0, 0, -0.04f), darkMat, sword, false);
        ProtoBuild.Box("Guard", new Vector3(0.12f, 0.018f, 0.018f), Vector3.zero, darkMat, sword, false);
        var sh = ProtoBuild.Box("Shield", new Vector3(0.16f, 0.2f, 0.02f), new Vector3(-0.42f, -0.34f, 0.8f), darkMat, cam.transform, false);
        sh.transform.localRotation = Quaternion.Euler(0, -23f, 0);
        shieldT = sh.transform; shieldR = sh.GetComponent<Renderer>();
    }

    static float Rand(System.Random r, float a, float b) { return a + (float)r.NextDouble() * (b - a); }

    void ResetFight()
    {
        pHp = playerMaxHp; pShield = maxShield; dodgeT = 0; dodgeCd = 0;
        eHp = enemyMaxHp; eState = EnemyState.Idle; idleT = 1.6f; atk = null; slashN = 0; deadT = 0;
        parryCombo = 0; fightLoot = new Dictionary<string, int>(); winDelay = -1f;
        if (enemy != null) Destroy(enemy.gameObject);
        enemy = ProtoEnemy.Create(new Vector3(0, 0, 4.5f));
    }

    void StartFight()
    {
        ResetFight();
        mode = Mode.Fight;
    }

    // ================= 毎フレーム =================
    void Update()
    {
        float dt = Mathf.Min(Time.deltaTime, 0.05f);
        time += dt;
        float dtE = dt;
        if (hitstop > 0) { hitstop -= dt; dtE = 0; }

        if (mode == Mode.Fight)
        {
            HandleInput();
            dodgeT = Mathf.Max(0, dodgeT - dt); dodgeCd = Mathf.Max(0, dodgeCd - dt);
            if (eState == EnemyState.Idle) { idleT -= dtE; if (idleT <= 0) StartChain(); }
            else if (eState == EnemyState.Attack)
            {
                atk.t += dtE;
                if (!atk.warned) { atk.warned = true; sfx.Warn(); }
                if (!atk.struck && atk.t >= atk.W) Strike();
                if (mode == Mode.Fight && atk != null && atk.t >= atk.W + 0.15f + 0.32f)
                {
                    idx++;
                    if (idx < chain.Count) NextAttack(); else EndChain();
                }
            }
            else if (eState == EnemyState.Break) { breakT -= dtE; if (breakT <= 0) { eState = EnemyState.Idle; idleT = 0.7f; } }
        }
        if (eState == EnemyState.Dead) deadT += dtE;
        if (winDelay > 0) { winDelay -= dt; if (winDelay <= 0) { winDelay = -1f; mode = Mode.Result; } }

        if (enemy != null) enemy.Pose(time, eState, atk, deadT);
        UpdateCamera(dt);
        UpdateViewModel(dt);
        UpdateSparks(dt);
        UpdateTrails(dt);
        msgT = Mathf.Max(0, msgT - dt);
        hurtFlash = Mathf.Max(0, hurtFlash - dt);
    }

    // ================= 入力 =================
    void HandleInput()
    {
        if (ProtoInput.DodgeLeft) Dodge(-1);
        if (ProtoInput.DodgeRight) Dodge(1);
        guard = ProtoInput.GuardHeld;

        float s = Screen.height / 720f;
        Vector2 mp = ProtoInput.MousePos;
        if (ProtoInput.LeftPressed) { dragging = true; dragDone = false; drag0 = mp; dragPts.Clear(); dragPts.Add(mp); }
        if (dragging && !dragDone)
        {
            if ((mp - dragPts[dragPts.Count - 1]).sqrMagnitude > 1f) dragPts.Add(mp);
            if ((mp - drag0).magnitude >= 60f * s) CompleteSwipe();
        }
        if (ProtoInput.LeftReleased)
        {
            if (dragging && !dragDone && (mp - drag0).magnitude >= 25f * s) CompleteSwipe();
            dragging = false;
        }
    }

    static char DirOf(Vector2 d)
    {
        if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) return d.x > 0 ? 'R' : 'L';
        return d.y > 0 ? 'U' : 'D';   // Unityの画面座標は上がプラス
    }

    void CompleteSwipe()
    {
        dragDone = true;
        var last = dragPts[dragPts.Count - 1];
        char dir = DirOf(last - drag0);
        AddTrail(new List<Vector2>(dragPts), eState == EnemyState.Break ? new Color(1f, 0.48f, 0.1f) : new Color(0.13f, 0.13f, 0.13f));
        swingDir = dir; swingT = 0;
        sfx.Slash();
        if (eState == EnemyState.Attack) TryParry(dir);
        else if (eState == EnemyState.Idle) AttackGuarded();
        else if (eState == EnemyState.Break) AttackBreak();
    }

    void Dodge(int side)
    {
        if (dodgeCd > 0) return;
        dodgeT = 0.42f; dodgeDir = side; dodgeCd = 0.6f;
        sfx.Dodge();
    }

    // ================= 敵の攻撃 =================
    void StartChain()
    {
        float ratio = eHp / enemyMaxHp;
        int n = ratio > 0.66f ? 2 : ratio > 0.33f ? 3 : 4;
        chain.Clear();
        char[] dirs = { 'R', 'L', 'D' };
        for (int i = 0; i < n; i++) chain.Add(dirs[Random.Range(0, 3)]);
        idx = 0; chainOK = 0; chainHit = false; tParry = tDodge = tBlock = false;
        eState = EnemyState.Attack;
        NextAttack();
    }

    void NextAttack()
    {
        char dir = chain[idx];
        float W = (idx == 0 ? 0.95f : 0.7f) * (eHp / enemyMaxHp < 0.33f ? 0.88f : 1f);
        atk = new Attack { dir = dir, need = NEED[dir], W = W, t = 0 };
    }

    void TryParry(char dir)
    {
        var a = atk;
        if (a == null || a.struck || a.failed) return;
        if (a.t < a.W - parryWindow) { a.failed = true; Msg("早い！", new Color(0.5f, 0.5f, 0.5f), 26); return; }
        if (dir != a.need) { a.failed = true; Msg("向きが違う", new Color(0.5f, 0.5f, 0.5f), 26); return; }
        // パリィ成功
        a.parried = true; a.struck = true; a.t = a.W + 0.16f;
        parryCombo++; chainOK++; tParry = true;
        hitstop = 0.07f + Mathf.Min(parryCombo, 10) * 0.012f;
        shake = 0.12f; punch = 1f;
        sfx.Parry(parryCombo);
        var p = new Vector3(a.dir == 'R' ? -0.5f : a.dir == 'L' ? 0.5f : 0, 2.4f, -0.6f);
        SpawnSparks(p, 16 + parryCombo * 2, sparkMat, 6f);
        SpawnSparks(p, 6, sparkWMat, 4f);
        Msg(parryCombo >= 2 ? "PARRY ×" + parryCombo : "PARRY", new Color(0.78f, 0.06f, 0.18f), 34);
    }

    void Strike()
    {
        var a = atk; a.struck = true;
        if (!a.failed && dodgeT > 0) { chainOK++; tDodge = true; Msg("回避", new Color(0.33f, 0.33f, 0.33f), 26); return; }
        if (!a.failed && guard && pShield > 0)
        {
            pShield--; chainOK++; tBlock = true;
            sfx.Block(); shake = 0.15f;
            SpawnSparks(new Vector3(-0.4f, 2.0f, -1.2f), 8, sparkWMat, 3f);
            Msg(pShield == 0 ? "盾が壊れた" : "ガード", new Color(0.33f, 0.33f, 0.33f), 26);
            return;
        }
        // 被弾
        float dmg = a.dir == 'D' ? 24f : 18f;
        pHp -= dmg; chainHit = true; parryCombo = 0;
        sfx.Hurt(); shake = 0.35f; hitstop = 0.06f; hurtFlash = 0.12f;
        if (pHp <= 0) Lose();
    }

    void EndChain()
    {
        if (!chainHit && chainOK == chain.Count)
        {
            float t = tParry ? 2.2f + Mathf.Min(parryCombo, 10) * 0.12f : tDodge ? 1.6f : 1.2f;
            t += weapon.brk;
            eState = EnemyState.Break; breakT = t; slashN = 0;
            sfx.Break(); Msg("崩し！", new Color(0.78f, 0.06f, 0.18f), 40);
        }
        else { eState = EnemyState.Idle; idleT = Random.Range(1.1f, 1.9f); }
        atk = null;
    }

    // ================= プレイヤーの攻撃 =================
    bool PartUnder(out ProtoEnemy.Part part, out Vector3 point)
    {
        part = null; point = Vector3.zero;
        bool bodyHit = false;
        Vector2[] samples = { dragPts[0], dragPts[dragPts.Count / 2], dragPts[dragPts.Count - 1] };
        foreach (var s in samples)
        {
            var ray = cam.ScreenPointToRay(new Vector3(s.x, s.y, 0));
            if (!Physics.Raycast(ray, out RaycastHit hit, 60f)) continue;
            if (enemy.colliderToPart.TryGetValue(hit.collider, out var p) && !p.broken) { part = p; point = hit.point; return true; }
            if (!bodyHit && (enemy.bodyColliders.Contains(hit.collider) || enemy.colliderToPart.ContainsKey(hit.collider))) { bodyHit = true; point = hit.point; }
        }
        return bodyHit;
    }

    void AttackGuarded()
    {
        if (!PartUnder(out _, out Vector3 pt)) return;
        eHp -= 10f * weapon.mul * 0.2f;
        sfx.Guarded(); SpawnSparks(pt, 5, sparkWMat, 2.5f);
        Msg("構えている", new Color(0.5f, 0.5f, 0.5f), 22);
        idleT = Mathf.Min(idleT, 0.5f);
        CheckDead();
    }

    void AttackBreak()
    {
        if (!PartUnder(out var part, out Vector3 pt)) return;
        slashN++;
        float dmg = 10f * weapon.mul * (1f + 0.06f * Mathf.Min(slashN, 10));
        eHp -= dmg;
        sfx.Cut(); hitstop = 0.035f; shake = 0.06f;
        SpawnSparks(pt, 10, redMat, 4f);
        if (part != null) { part.cur -= dmg; if (part.cur <= 0) BreakPart(part); }
        if (slashN >= 2) Msg(slashN + " HIT", new Color(0.13f, 0.13f, 0.13f), 26);
        CheckDead();
    }

    void BreakPart(ProtoEnemy.Part p)
    {
        p.broken = true;
        enemy.DetachPart(p);
        Add(fightLoot, p.mat, 1);
        hitstop = 0.18f; shake = 0.4f; punch = 1.4f;
        sfx.Part(); Msg("部位破壊！ " + p.mat + "を入手", new Color(0.78f, 0.06f, 0.18f), 30);
    }

    void CheckDead()
    {
        if (eHp <= 0 && eState != EnemyState.Dead) { eState = EnemyState.Dead; deadT = 0; Win(); }
    }

    // ================= 勝敗・素材 =================
    static void Add(Dictionary<string, int> d, string k, int n) { d[k] = (d.ContainsKey(k) ? d[k] : 0) + n; }

    string LootText(Dictionary<string, int> d)
    {
        var sb = new System.Text.StringBuilder();
        foreach (var kv in d) if (kv.Value > 0) sb.Append(kv.Key).Append(" ×").Append(kv.Value).Append(kv.Key == "紅玉" ? "  レア！" : "").Append("\n");
        return sb.Length > 0 ? sb.ToString() : "なし";
    }

    void Win()
    {
        var loot = new Dictionary<string, int>(fightLoot);
        Add(loot, "甲殻", 2 + Random.Range(0, 2));
        if (Random.value < rareDropRate) Add(loot, "紅玉", 1);
        foreach (var kv in loot) Add(inv, kv.Key, kv.Value);
        int broken = 0; foreach (var p in enemy.parts) if (p.broken) broken++;
        resTitle = "撃破";
        resSub = "部位破壊 " + broken + "／" + enemy.parts.Count;
        resLoot = "手に入れた素材\n" + LootText(loot);
        winDelay = 1.4f;
    }

    void Lose()
    {
        foreach (var kv in fightLoot) Add(inv, kv.Key, kv.Value);
        resTitle = "力尽きた";
        resSub = "船の再生装置で再起動。この周回の最初に戻る。";
        resLoot = "持ち帰った素材（ロストなし）\n" + LootText(fightLoot);
        mode = Mode.Result;
    }

    bool CanCraft(Weapon w)
    {
        if (w.req == null) return false;
        foreach (var kv in w.req) if ((inv.ContainsKey(kv.Key) ? inv[kv.Key] : 0) < kv.Value) return false;
        return true;
    }

    void Msg(string t, Color c, int size) { msgText = t; msgColor = c; msgSize = size; msgT = 0.85f; }

    // ================= 演出 =================
    void SpawnSparks(Vector3 pos, int n, Material mat, float speed)
    {
        for (int i = 0; i < n; i++)
        {
            var g = ProtoBuild.Box("Spark", Vector3.one * 0.05f, pos, mat, null, false);
            var v = new Vector3(Random.Range(-1f, 1f), Random.Range(-0.3f, 1.2f), Random.Range(-1f, 0.2f)).normalized * Random.Range(speed * 0.4f, speed);
            sparks.Add(new Spark { t = g.transform, v = v, life = Random.Range(0.25f, 0.5f) });
        }
    }

    void UpdateSparks(float dt)
    {
        for (int i = sparks.Count - 1; i >= 0; i--)
        {
            var s = sparks[i];
            s.life -= dt; s.v.y -= 9f * dt; s.t.position += s.v * dt;
            if (s.life <= 0) { Destroy(s.t.gameObject); sparks.RemoveAt(i); }
        }
    }

    void AddTrail(List<Vector2> pts, Color c)
    {
        var g = new GameObject("Trail");
        var lr = g.AddComponent<LineRenderer>();
        lr.material = lineMat; lr.useWorldSpace = true; lr.widthMultiplier = 0.006f;
        lr.numCapVertices = 4; lr.numCornerVertices = 2;
        lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        trails.Add(new Trail { lr = lr, pts = pts, life = 0.28f, max = 0.28f, c = c });
    }

    void UpdateTrails(float dt)
    {
        for (int i = trails.Count - 1; i >= 0; i--)
        {
            var t = trails[i];
            t.life -= dt;
            if (t.life <= 0) { Destroy(t.lr.gameObject); trails.RemoveAt(i); continue; }
            var c = t.c; c.a = Mathf.Clamp01(t.life / t.max);
            t.lr.startColor = c; t.lr.endColor = c;
            t.lr.positionCount = t.pts.Count;
            for (int j = 0; j < t.pts.Count; j++)
                t.lr.SetPosition(j, cam.ScreenToWorldPoint(new Vector3(t.pts[j].x, t.pts[j].y, 0.3f)));
        }
    }

    void UpdateCamera(float dt)
    {
        Vector3 p = CAM;
        if (dodgeT > 0)
        {
            float k = Mathf.Sin((1f - dodgeT / 0.42f) * Mathf.PI);
            p.x += dodgeDir * 1.3f * k; p.z -= 0.4f * k; p.y -= 0.25f * k;
        }
        if (shake > 0) { shake = Mathf.Max(0, shake - dt); p.x += Random.Range(-1f, 1f) * shake * 0.5f; p.y += Random.Range(-1f, 1f) * shake * 0.5f; }
        cam.transform.position = p;
        cam.transform.LookAt(new Vector3(LOOK.x + (p.x - CAM.x) * 0.4f, LOOK.y, LOOK.z));
        if (punch > 0) punch = Mathf.Max(0, punch - dt * 4f);
        cam.fieldOfView = 60f - 6f * punch;
    }

    static readonly Vector3 SWORD_POS = new Vector3(0.36f, -0.3f, 0.7f);
    static readonly Vector3 SWORD_ROT = new Vector3(-35f, -15f, -25f);
    void UpdateViewModel(float dt)
    {
        bool g = guard && mode == Mode.Fight;
        shieldT.localPosition = Vector3.Lerp(shieldT.localPosition, g ? new Vector3(-0.08f, -0.1f, 0.55f) : new Vector3(-0.42f, -0.34f, 0.8f), 0.3f);
        shieldR.sharedMaterial = pShield > 0 ? darkMat : rockMat;

        if (swingT >= 0)
        {
            swingT += dt;
            float k = Mathf.Clamp01(swingT / 0.16f), e = 1f - Mathf.Pow(1f - k, 3f);
            Vector3 from, to;
            switch (swingDir)
            {
                case 'L': from = new Vector3(-20f, 50f, -30f); to = new Vector3(-20f, -60f, 30f); break;
                case 'R': from = new Vector3(-20f, -60f, 30f); to = new Vector3(-20f, 50f, -30f); break;
                case 'U': from = new Vector3(40f, -10f, 0); to = new Vector3(-70f, -10f, 0); break;
                default: from = new Vector3(-70f, -10f, 0); to = new Vector3(30f, -10f, 0); break;
            }
            sword.localRotation = Quaternion.Euler(Vector3.Lerp(from, to, e));
            sword.localPosition = new Vector3(Mathf.Lerp(0.25f, 0.05f, Mathf.Sin(k * Mathf.PI)), -0.22f, 0.7f);
            if (k >= 1f) swingT = -1f;
        }
        else
        {
            sword.localRotation = Quaternion.Slerp(sword.localRotation, Quaternion.Euler(SWORD_ROT), 0.2f);
            sword.localPosition = Vector3.Lerp(sword.localPosition, SWORD_POS, 0.2f);
        }
    }

    // ================= 画面表示（OnGUI） =================
    GUIStyle sLabel, sCenter, sBig, sTele, sPanel, sBtn, sSmall;
    static readonly Color RED = new Color(0.78f, 0.06f, 0.18f);
    static readonly Color INK = new Color(0.13f, 0.13f, 0.13f);

    void InitStyles()
    {
        if (sLabel != null) return;
        sLabel = new GUIStyle(GUI.skin.label) { fontSize = 14, wordWrap = true };
        sLabel.normal.textColor = INK;
        if (uiFont) sLabel.font = uiFont;
        sSmall = new GUIStyle(sLabel) { fontSize = 12 };
        sCenter = new GUIStyle(sLabel) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
        sBig = new GUIStyle(sCenter) { fontSize = 34 };
        sTele = new GUIStyle(sCenter) { fontSize = 90 };
        sPanel = new GUIStyle(GUI.skin.box) { padding = new RectOffset(18, 18, 14, 14), alignment = TextAnchor.UpperLeft, fontSize = 14, wordWrap = true };
        sPanel.normal.background = Texture2D.whiteTexture; sPanel.normal.textColor = INK;
        if (uiFont) sPanel.font = uiFont;
        sBtn = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, fixedHeight = 40 };
        if (uiFont) sBtn.font = uiFont;
    }

    static void Fill(Rect r, Color c) { var o = GUI.color; GUI.color = c; GUI.DrawTexture(r, Texture2D.whiteTexture); GUI.color = o; }

    void Label(Rect r, string t, GUIStyle st, Color c, int size = 0)
    {
        var o = st.normal.textColor; int os = st.fontSize;
        st.normal.textColor = c; if (size > 0) st.fontSize = size;
        GUI.Label(r, t, st);
        st.normal.textColor = o; st.fontSize = os;
    }

    void OnGUI()
    {
        InitStyles();
        float s = Screen.height / 720f, W = Screen.width / s, H = 720f;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(s, s, 1));

        if (hurtFlash > 0) Fill(new Rect(0, 0, W, H), new Color(0.78f, 0.06f, 0.18f, 0.25f));
        DrawHud(W, H);

        if (mode == Mode.Title) DrawTitle(W, H);
        else if (mode == Mode.Result) DrawResult(W, H);
        else if (mode == Mode.Shop) DrawShop(W, H);
    }

    void DrawHud(float W, float H)
    {
        // 敵
        float bw = Mathf.Min(560f, W * 0.8f), bx = (W - bw) / 2f;
        Label(new Rect(bx, 10, bw, 22), "棘甲獣（仮）", sCenter, INK, 14);
        Fill(new Rect(bx, 36, bw, 10), new Color(0, 0, 0, 0.12f));
        Fill(new Rect(bx, 36, bw * Mathf.Clamp01(eHp / enemyMaxHp), 10), RED);
        if (enemy != null)
        {
            float px = W / 2f - enemy.parts.Count * 32f;
            foreach (var p in enemy.parts)
            {
                var r = new Rect(px, 52, 58, 20);
                        Fill(r, new Color(1, 1, 1, p.broken ? 0.25f : 0.7f));
                Label(r, p.broken ? "×" + p.name : p.name, sCenter, p.broken ? new Color(0, 0, 0, 0.35f) : INK, 11);
                px += 64f;
            }
        }
        // 操作説明
        Fill(new Rect(14, 12, 300, 62), new Color(1, 1, 1, 0.55f));
        Label(new Rect(22, 14, 290, 60), "ドラッグ：斬る／パリィ（矢印の方向）\nA / D：回避　S か右クリック長押し：ガード\n連続攻撃を全部しのぐ → 崩し → 部位を狙って斬る", sSmall, INK, 11);
        // プレイヤー
        Label(new Rect(16, H - 92, 100, 18), "HP", sSmall, INK, 11);
        Fill(new Rect(16, H - 74, 260, 10), new Color(0, 0, 0, 0.12f));
        Fill(new Rect(16, H - 74, 260 * Mathf.Clamp01(pHp / playerMaxHp), 10), INK);
        Label(new Rect(16, H - 58, 100, 18), "盾", sSmall, INK, 11);
        for (int i = 0; i < maxShield; i++) Fill(new Rect(16 + i * 22, H - 38, 18, 10), i < pShield ? INK : new Color(0, 0, 0, 0.15f));
        // 武器
        var right = new GUIStyle(sLabel) { alignment = TextAnchor.LowerRight, fontStyle = FontStyle.Bold };
        Label(new Rect(W - 316, H - 60, 300, 22), weapon.name, right, INK, 14);
        Label(new Rect(W - 316, H - 38, 300, 20), "攻撃 ×" + weapon.mul + (weapon.brk > 0 ? "／崩し +" + weapon.brk + "秒" : ""), right, INK, 12);
        // 連続パリィ
        if (parryCombo >= 2)
        {
            var rs = new GUIStyle(sLabel) { alignment = TextAnchor.UpperRight, fontStyle = FontStyle.Bold };
            Label(new Rect(W - 224, 64, 200, 40), parryCombo.ToString(), rs, RED, 30);
            Label(new Rect(W - 224, 100, 200, 20), "連続パリィ", rs, INK, 11);
        }
        // 予兆の矢印
        if (mode == Mode.Fight && eState == EnemyState.Attack && atk != null && !atk.struck)
        {
            bool inWin = atk.t >= atk.W - parryWindow;
            float a = atk.failed ? 0.25f : Mathf.Clamp01(atk.t / 0.25f);
            int size = inWin ? 112 : 90;
            var r = new Rect(W / 2f - 100, H / 2f - 100, 200, 200);
            if (inWin)
            {
                for (int i = 0; i < 8; i++)
                {
                    float ang = i * Mathf.PI / 4f;
                    Label(new Rect(r.x + Mathf.Cos(ang) * 4, r.y + Mathf.Sin(ang) * 4, r.width, r.height), ARROW[atk.need], sTele, new Color(RED.r, RED.g, RED.b, a * 0.6f), size);
                }
                Label(r, ARROW[atk.need], sTele, new Color(1, 1, 1, a), size);
            }
            else Label(r, ARROW[atk.need], sTele, new Color(RED.r, RED.g, RED.b, a), size);
        }
        // メッセージ
        if (msgT > 0)
        {
            float a = Mathf.Clamp01(msgT / 0.5f);
            var r = new Rect(0, H * 0.3f - 30, W, 60);
            Label(new Rect(r.x, r.y + 2, r.width, r.height), msgText, sBig, new Color(1, 1, 1, a), msgSize);
            Label(r, msgText, sBig, new Color(msgColor.r, msgColor.g, msgColor.b, a), msgSize);
        }
    }

    Rect Panel(float W, float H, float w, float h) { var r = new Rect((W - w) / 2f, (H - h) / 2f, w, h); return r; }

    void DrawTitle(float W, float H)
    {
        Fill(new Rect(0, 0, W, H), new Color(0.914f, 0.906f, 0.886f, 0.92f));
        var r = Panel(W, H, 600, 520);
        GUILayout.BeginArea(r);
        Label(GUILayoutUtility.GetRect(600, 44), "試作 01", sCenter, INK, 30);
        Label(GUILayoutUtility.GetRect(600, 26), "墜落した惑星。最初の生命体と戦う。", sCenter, INK, 14);
        GUILayout.Space(8);
        GUILayout.Box(
            "【操作】\n" +
            "・マウスでドラッグ：斬る。敵の攻撃中は画面中央の矢印の方向にドラッグでパリィ\n" +
            "・矢印が白く光った瞬間がパリィのタイミング\n" +
            "・A / D：回避　S か右クリック長押し：ガード（盾は回数制限）\n\n" +
            "【流れ】\n" +
            "・構えている敵には攻撃がほぼ通らない\n" +
            "・敵の連続攻撃を全部しのぐと崩し（パリィで崩すと長い・連続パリィでさらに延長）\n" +
            "・崩し中に角・爪・背棘を狙って斬ると部位破壊 → その部位の素材が確定で手に入る\n" +
            "・素材を集めて工房で武器を作る。負けても素材は失われない", sPanel, GUILayout.Width(600));
        GUILayout.Space(10);
        if (GUILayout.Button("戦う", sBtn)) StartFight();
        GUILayout.EndArea();
    }

    void DrawResult(float W, float H)
    {
        Fill(new Rect(0, 0, W, H), new Color(0.914f, 0.906f, 0.886f, 0.92f));
        var r = Panel(W, H, 420, 360);
        GUILayout.BeginArea(r);
        Label(GUILayoutUtility.GetRect(420, 40), resTitle, sCenter, INK, 26);
        Label(GUILayoutUtility.GetRect(420, 40), resSub, sCenter, INK, 14);
        GUILayout.Box(resLoot, sPanel, GUILayout.Width(420), GUILayout.MinHeight(120));
        GUILayout.Space(10);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("もう一度戦う", sBtn)) StartFight();
        if (GUILayout.Button("工房へ", sBtn)) mode = Mode.Shop;
        GUILayout.EndHorizontal();
        GUILayout.EndArea();
    }

    void DrawShop(float W, float H)
    {
        Fill(new Rect(0, 0, W, H), new Color(0.914f, 0.906f, 0.886f, 0.94f));
        var r = Panel(W, H, 560, 560);
        GUILayout.BeginArea(r);
        Label(GUILayoutUtility.GetRect(560, 40), "工房", sCenter, INK, 24);
        Label(GUILayoutUtility.GetRect(560, 24), "船の残骸と、集めた素材で武器を作る。", sCenter, INK, 13);
        var sb = new System.Text.StringBuilder("素材\n");
        foreach (var kv in inv) sb.Append(kv.Key).Append(" ×").Append(kv.Value).Append("　");
        sb.Append("\n甲殻：撃破で確定　爪・棘・角：部位破壊で確定　紅玉：撃破時に低確率");
        GUILayout.Box(sb.ToString(), sPanel, GUILayout.Width(560));
        GUILayout.Space(6);
        foreach (var w in weapons)
        {
            GUILayout.BeginHorizontal(sPanel, GUILayout.Width(560));
            string req = "初期装備";
            if (w.req != null) { var rb = new System.Text.StringBuilder(); foreach (var kv in w.req) rb.Append(kv.Key).Append(kv.Value).Append(" "); req = rb.ToString(); }
            GUILayout.Label("<b>" + w.name + "</b>\n" + w.desc + "／" + req, new GUIStyle(sLabel) { richText = true, fontSize = 13 }, GUILayout.Width(390));
            if (owned.Contains(w.id))
            {
                GUI.enabled = weapon != w;
                if (GUILayout.Button(weapon == w ? "装備中" : "装備", sBtn, GUILayout.Width(110))) weapon = w;
                GUI.enabled = true;
            }
            else
            {
                GUI.enabled = CanCraft(w);
                if (GUILayout.Button("作る", sBtn, GUILayout.Width(110)))
                {
                    foreach (var kv in w.req) inv[kv.Key] -= kv.Value;
                    owned.Add(w.id); weapon = w; sfx.Break();
                }
                GUI.enabled = true;
            }
            GUILayout.EndHorizontal();
        }
        GUILayout.Space(8);
        if (GUILayout.Button("戦いに行く", sBtn)) StartFight();
        GUILayout.EndArea();
    }
}
