using System.Collections.Generic;
using UnityEngine;

// 敵（棘甲獣・仮）の見た目とポーズ。カメラは -Z 側から +Z を見ている前提
public class ProtoEnemy : MonoBehaviour
{
    public class Part
    {
        public string key, name, mat;
        public float hp, cur;
        public bool broken;
        public List<GameObject> objs = new List<GameObject>();
    }

    public Transform torso, armLPivot, armRPivot;
    public Material white, dark, partMat, red;
    public readonly List<Part> parts = new List<Part>();
    public readonly Dictionary<Collider, Part> colliderToPart = new Dictionary<Collider, Part>();
    public readonly HashSet<Collider> bodyColliders = new HashSet<Collider>();
    Color whiteBase = new Color(0.965f, 0.96f, 0.945f);

    public static ProtoEnemy Create(Vector3 pos)
    {
        var root = new GameObject("Enemy");
        root.transform.position = pos;
        var e = root.AddComponent<ProtoEnemy>();
        e.Build();
        return e;
    }

    void Build()
    {
        white = ProtoBuild.Lit(whiteBase);
        dark = ProtoBuild.Lit(new Color(0.18f, 0.17f, 0.2f));
        partMat = ProtoBuild.Lit(new Color(0.42f, 0.106f, 0.133f));
        red = ProtoBuild.Unlit(new Color(0.78f, 0.06f, 0.18f));

        var t = transform;
        AddBody(ProtoBuild.Box("LegL", new Vector3(0.75f, 1.6f, 0.75f), new Vector3(-0.75f, 0.8f, 0), dark, t));
        AddBody(ProtoBuild.Box("LegR", new Vector3(0.75f, 1.6f, 0.75f), new Vector3(0.75f, 0.8f, 0), dark, t));

        torso = new GameObject("Torso").transform; torso.SetParent(t, false);
        AddBody(ProtoBuild.Box("Body", new Vector3(2.5f, 2.2f, 1.6f), new Vector3(0, 2.6f, 0), white, torso));
        AddBody(ProtoBuild.Box("Head", new Vector3(1.3f, 1.0f, 1.2f), new Vector3(0, 4.1f, -0.3f), white, torso));
        ProtoBuild.Box("EyeL", new Vector3(0.22f, 0.12f, 0.05f), new Vector3(-0.3f, 4.2f, -0.92f), red, torso, false);
        ProtoBuild.Box("EyeR", new Vector3(0.22f, 0.12f, 0.05f), new Vector3(0.3f, 4.2f, -0.92f), red, torso, false);

        var horn = ProtoBuild.Cone("Horn", 0.24f, 1.1f, 6, new Vector3(0, 5.1f, -0.4f), new Vector3(-14f, 0, 0), partMat, torso);

        armLPivot = MakeArm(-1, out var clawL);
        armRPivot = MakeArm(1, out var clawR);

        var spL = ProtoBuild.Cone("SpikeL", 0.2f, 1.4f, 5, new Vector3(-0.95f, 4.2f, 0.45f), new Vector3(20f, 0, 20f), partMat, torso);
        var spR = ProtoBuild.Cone("SpikeR", 0.2f, 1.4f, 5, new Vector3(0.95f, 4.2f, 0.45f), new Vector3(20f, 0, -20f), partMat, torso);

        AddPart("horn", "角", "角", 40, horn);
        AddPart("clawL", "左爪", "爪", 32, clawL);
        AddPart("clawR", "右爪", "爪", 32, clawR);
        AddPart("spikes", "背棘", "棘", 44, spL, spR);
    }

    Transform MakeArm(int side, out GameObject claw)
    {
        var p = new GameObject(side < 0 ? "ArmL" : "ArmR").transform;
        p.SetParent(torso, false);
        p.localPosition = new Vector3(1.6f * side, 3.45f, 0);
        AddBody(ProtoBuild.Box("Arm", new Vector3(0.6f, 2.1f, 0.6f), new Vector3(0, -1.05f, 0), white, p));
        claw = ProtoBuild.Cone("Claw", 0.34f, 0.95f, 5, new Vector3(0, -2.55f, 0), new Vector3(0, 0, 180f), partMat, p);
        return p;
    }

    void AddBody(GameObject g) { var c = g.GetComponent<Collider>(); if (c) bodyColliders.Add(c); }

    void AddPart(string key, string name, string mat, float hp, params GameObject[] objs)
    {
        var p = new Part { key = key, name = name, mat = mat, hp = hp, cur = hp };
        foreach (var o in objs) { p.objs.Add(o); var c = o.GetComponent<Collider>(); if (c) colliderToPart[c] = p; }
        parts.Add(p);
    }

    // 部位を体から外して飛ばす
    public void DetachPart(Part p)
    {
        foreach (var o in p.objs)
        {
            var c = o.GetComponent<Collider>(); if (c) colliderToPart.Remove(c);
            o.transform.SetParent(null, true);
            var rb = o.AddComponent<Rigidbody>();
            var vel = new Vector3(Random.Range(-2f, 2f), Random.Range(3f, 5f), Random.Range(-3f, -1f));
#if UNITY_6000_0_OR_NEWER
            rb.linearVelocity = vel;
#else
            rb.velocity = vel;
#endif
            rb.angularVelocity = Random.insideUnitSphere * 8f;
            Destroy(o, 3f);
        }
    }

    // JS版と同じ値（ラジアン）で受け取る。X回転は向きが逆なので符号を反転する
    static void Arm(Transform pivot, float z, float x)
    {
        pivot.localRotation = Quaternion.Euler(-x * Mathf.Rad2Deg, 0, z * Mathf.Rad2Deg);
    }

    float leanCur;
    public void Pose(float time, ProtoGame.EnemyState state, ProtoGame.Attack a, float deadT)
    {
        float lz = 0.08f, lx = 0, rz = -0.08f, rx = 0, lean = 0, sway = Mathf.Sin(time * 2f) * 0.04f;
        if (state == ProtoGame.EnemyState.Attack && a != null)
        {
            float W = a.W;
            float p = EaseOut(Mathf.Clamp01(a.t / W)), s = Mathf.Clamp01((a.t - W) / 0.15f), r = Mathf.Clamp01((a.t - W - 0.15f) / 0.3f);
            if (a.dir == 'R')
            {
                float wz = -2.1f, wx = 0.35f, sz = 1.25f, sx = -0.9f;
                lz = a.t < W ? Mathf.Lerp(0.08f, wz, p) : r > 0 ? Mathf.Lerp(sz, 0.08f, r) : Mathf.Lerp(wz, sz, s);
                lx = a.t < W ? Mathf.Lerp(0, wx, p) : r > 0 ? Mathf.Lerp(sx, 0, r) : Mathf.Lerp(wx, sx, s);
                lean = a.t < W ? -0.12f * p : 0.15f;
            }
            else if (a.dir == 'L')
            {
                float wz = 2.1f, wx = 0.35f, sz = -1.25f, sx = -0.9f;
                rz = a.t < W ? Mathf.Lerp(-0.08f, wz, p) : r > 0 ? Mathf.Lerp(sz, -0.08f, r) : Mathf.Lerp(wz, sz, s);
                rx = a.t < W ? Mathf.Lerp(0, wx, p) : r > 0 ? Mathf.Lerp(sx, 0, r) : Mathf.Lerp(wx, sx, s);
                lean = a.t < W ? -0.12f * p : 0.15f;
            }
            else
            {
                float ux = -2.8f, dx = -0.45f;
                lx = rx = a.t < W ? Mathf.Lerp(0, ux, p) : r > 0 ? Mathf.Lerp(dx, 0, r) : Mathf.Lerp(ux, dx, s);
                lz = 0.25f; rz = -0.25f;
                lean = a.t < W ? -0.2f * p : 0.25f;
            }
            if (a.parried && r < 1) lean = -0.25f * (1 - r);
        }
        else if (state == ProtoGame.EnemyState.Break)
        {
            lean = -0.22f + Mathf.Sin(time * 9f) * 0.03f; lz = -0.85f; rz = 0.85f; lx = rx = -0.35f;
        }
        Arm(armLPivot, lz, lx);
        Arm(armRPivot, rz, rx);
        leanCur = Mathf.Lerp(leanCur, lean, state == ProtoGame.EnemyState.Attack ? 0.5f : 0.15f);
        torso.localRotation = Quaternion.Euler(-leanCur * Mathf.Rad2Deg, 0, 0);
        torso.localPosition = new Vector3(0, sway, 0);

        // 崩し中は赤く明滅
        if (state == ProtoGame.EnemyState.Break)
        {
            float k = 0.15f + 0.1f * Mathf.Sin(time * 12f);
            ProtoBuild.SetColor(white, Color.Lerp(whiteBase, new Color(1f, 0.45f, 0.45f), k * 2f));
        }
        else ProtoBuild.SetColor(white, whiteBase);

        if (state == ProtoGame.EnemyState.Dead)
        {
            float k = Mathf.Clamp01(deadT * 1.5f);
            transform.rotation = Quaternion.Euler(Mathf.Lerp(0, 90f, EaseOut(k)), 0, 0);
            var pos = transform.position; pos.y = Mathf.Lerp(0, -0.6f, k); transform.position = pos;
        }
    }

    static float EaseOut(float t) { return 1f - Mathf.Pow(1f - t, 3f); }
}
