using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

// 旧Input Manager／新Input System のどちらでも動く入力まとめ
public static class ProtoInput
{
    public static Vector2 MousePos
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null ? Mouse.current.position.ReadValue() : Vector2.zero;
#else
            return Input.mousePosition;
#endif
        }
    }

    public static bool LeftPressed
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame;
#else
            return Input.GetMouseButtonDown(0);
#endif
        }
    }

    public static bool LeftReleased
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null && Mouse.current.leftButton.wasReleasedThisFrame;
#else
            return Input.GetMouseButtonUp(0);
#endif
        }
    }

    public static bool RightHeld
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null && Mouse.current.rightButton.isPressed;
#else
            return Input.GetMouseButton(1);
#endif
        }
    }

    public static bool DodgeLeft
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current; return k != null && (k.aKey.wasPressedThisFrame || k.leftArrowKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow);
#endif
        }
    }

    public static bool DodgeRight
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current; return k != null && (k.dKey.wasPressedThisFrame || k.rightArrowKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow);
#endif
        }
    }

    public static bool GuardHeld
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            bool key = k != null && (k.sKey.isPressed || k.downArrowKey.isPressed || k.leftShiftKey.isPressed);
            return key || RightHeld;
#else
            return Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.LeftShift) || RightHeld;
#endif
        }
    }
}
